let session = sessionStorage.getItem('registered');
let i = 0;
let speed = 60;
let text = "You are succesfully registered. Now you can login to this account.";
let users = [];

if(session == 1) {
    i = 0;
    document.getElementById('alertp').style.display = 'block';
    document.getElementById('alertp').innerHTML = '';
    document.getElementById('alertRegister').style.display = 'flex'; 
    text = "You are succesfully registered. Now you can login to this account.";
    typeWriter();
    setTimeout(function() {
        document.getElementById('alertp').innerHTML = '';
        document.getElementById('alertRegister').style.display = 'none';
        i = 0;
    }, 5500);
    sessionStorage.setItem('registered', 0);
}


if(sessionStorage.getItem('account') != null) {
    let account = JSON.parse(sessionStorage.getItem('account'));
    document.getElementById('user').innerHTML = 'Welcome ' + account.full_name;
    document.getElementById('umail').innerHTML = account.email;
    document.getElementById('ufull_name').innerHTML = account.full_name;
    document.getElementById('ucountry').innerHTML = account.country;
    document.getElementById('ubirthdate').innerHTML = account.birthdate;
    document.getElementById('t').innerHTML = account.full_name;
}else {
    document.getElementById('mainC').style.display = 'none';
    document.getElementById('user').innerHTML = 'Please enter your account';
}

function addStorage() {
    let input_email = document.getElementById("email");
    let input_password = document.getElementById("password");
    let input_full_name = document.getElementById("full_name");
    let select_countries = document.getElementById("country");
    let input_birthdate = document.getElementById("birthdate");

    let user = {
        email: input_email.value,
        password: input_password.value,
        full_name: input_full_name.value,
        country: select_countries.value,
        birthdate: input_birthdate.value
    }
    let validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(isEmpty(user.email) || !(user.email).match(validRegex) || isEmpty(user.password) || isEmpty(user.full_name) || isEmpty(user.country) || isEmpty(user.birthdate)) {
        sessionStorage.setItem('registered', 0);
        document.getElementById('valEmail').style.visibility = 'hidden';
        document.getElementById('valPassword').style.visibility = 'hidden';
        document.getElementById('valFullName').style.visibility = 'hidden';
        document.getElementById('valBirthDate').style.visibility = 'hidden';
        if(isEmpty(user.email) || !(user.email).match(validRegex)) {
            document.getElementById('valEmail').style.visibility = 'visible';
            document.getElementById('valEmail').innerHTML = "*";
        }else if(isEmpty(user.password)) {
            document.getElementById('valPassword').style.visibility = 'visible';
            document.getElementById('valPassword').innerHTML = "*";
        }else if(isEmpty(user.full_name)) {
            document.getElementById('valFullName').style.visibility = 'visible';
            document.getElementById('valFullName').innerHTML = "*";
        }else if(isEmpty(user.birthdate)) {
            document.getElementById('valBirthDate').style.visibility = 'visible';
            document.getElementById('valBirthDate').innerHTML = "*";
        }
    }else {
        sessionStorage.setItem('registered', 1);
            if(localStorage.getItem('users') != null) {
                let u = JSON.parse(localStorage.users);
                u.push(user);
                let u_json = JSON.stringify(u);
                localStorage.setItem('users', u_json);
            }else {
                let u = [];
                u.push(user);
                let u_json = JSON.stringify(u);
                localStorage.setItem('users', u_json);
            }

            window.location.href = "login.html";
    }
}

function isEmpty(str) {
    return (!str.trim() || str.trim().length === 0);
}


function typeWriter() {
    if(i < text.length) {
        document.getElementById('alertp').innerHTML += text.charAt(i++);
        setTimeout(typeWriter, speed);
    }
}


function signIn() {
    let validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;
    document.getElementById('valEmail').style.visibility = 'hidden';
    document.getElementById('valPassword').style.visibility = 'hidden';

    if(isEmpty(email) || !email.match(validRegex)) {
        document.getElementById('valEmail').style.visibility = 'visible';
        document.getElementById('valEmail').innerHTML = "*";
    }else if(isEmpty(password)) {
        document.getElementById('valPassword').style.visibility = 'visible';
        document.getElementById('valPassword').innerHTML = "*";
    }else {
        if(localStorage.getItem('users') != null) {
            let us = JSON.parse(localStorage.users);
            let res = false;
            let account;
            for(let u of us) {
                if(email == u.email && password == u.password) {
                    account = u;
                    res = true;
                    break;
                }
            }

            if(res) {
                sessionStorage.setItem('account', JSON.stringify(account));
                window.location.href = "tweets.html";
            }else {
                    i = 0;
                    document.getElementById('alertp').style.display = 'block';
                    document.getElementById('alertp').innerHTML = '';
                    document.getElementById('alertRegister').style.display = 'flex';
                    text = "You entered email or password incorrectly";
                    typeWriter();
                    setTimeout(function() {
                        document.getElementById('alertp').innerHTML = '';
                        document.getElementById('alertRegister').style.display = 'none';
                        i = 0;
                    }, 3000);
            }
        }else {
            i = 0;
            document.getElementById('alertp').style.display = 'block';
            document.getElementById('alertp').innerHTML = '';
            document.getElementById('alertRegister').style.display = 'flex';
            text = "You entered email or password incorrectly";
            typeWriter();
            setTimeout(function() {
                document.getElementById('alertp').innerHTML = '';
                document.getElementById('alertRegister').style.display = 'none';
                i = 0;
            }, 3000);
        }
    }
}


function signOut() {
    sessionStorage.removeItem('account');
    document.getElementById('mainC').style.display = 'none';
    document.getElementById('user').innerHTML = 'Please enter your account';
    window.location.href = "login.html";
}
